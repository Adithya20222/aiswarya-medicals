Aiswarya Medicals website
==========================

Open index.html in any browser.

The website includes:
- Responsive mobile/desktop design
- Call button
- Google Maps directions
- Embedded map
- Opening hours
- Services section
- Pharmacy address and contact details

Before publishing, confirm the phone number, services, and business information with the shop owner.
